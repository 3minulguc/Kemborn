import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom'; // Dashboard'dan gelen parametreyi okumak için
import { FiEye, FiSearch, FiX, FiSave, FiPackage, FiMapPin, FiTruck, FiUser, FiCreditCard, FiCalendar, FiClock, FiCheckCircle, FiXCircle } from 'react-icons/fi';
import toast from 'react-hot-toast';
import { API_URL } from '../../config/api';

const AdminOrders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const PAGE_SIZE = 15;
  
  // URL parametrelerini dinleme aracı (?status=HAZIRLANIYOR gibi)
  const [searchParams, setSearchParams] = useSearchParams();
  const statusParam = searchParams.get('status')?.trim().toUpperCase() || 'ALL';

  // Aktif sekme state'i (Varsayılan olarak URL'den geleni alır, yoksa 'ALL' olur)
  const [activeTab, setActiveTab] = useState(statusParam);

  // Modal State'leri
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [detailsLoading, setDetailsLoading] = useState(false);
  const [editForm, setEditForm] = useState({ status: '', tracking_number: '' });
  const [saving, setSaving] = useState(false);

  // URL'deki status parametresi değişirse sekmeyi otomatik güncelle
  useEffect(() => {
    if (statusParam) {
      setActiveTab(statusParam);
    }
  }, [statusParam]);

  // 1. Tüm Siparişleri Çek
  const fetchOrders = async () => {
    try {
      const token = sessionStorage.getItem('kemborn_token');
      const res = await fetch(`${API_URL}/api/admin/orders`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      if (res.ok) {
        const data = await res.json();
        setOrders(data || []);
      } else {
        toast.error("Siparişler çekilemedi.");
      }
    } catch (error) {
      toast.error("Veritabanı bağlantı hatası.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  // 2. Sipariş Detayını Çek (Modal İçin)
  const handleViewOrder = async (orderId) => {
    setDetailsLoading(true);
    setSelectedOrder({ id: orderId }); 
    
    try {
      const token = sessionStorage.getItem('kemborn_token');
      const res = await fetch(`${API_URL}/api/orders/${orderId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedOrder(data);
        setEditForm({ 
            status: data.status ? data.status.toUpperCase() : 'HAZIRLANIYOR', 
            tracking_number: data.tracking_number || '' 
        });
      } else {
        throw new Error("Sipariş detayı bulunamadı.");
      }
    } catch (error) {
      toast.error("Sipariş detayları alınamadı.");
      setSelectedOrder(null);
    } finally {
      setDetailsLoading(false);
    }
  };

  // 3. Siparişi Güncelle (Kaydet)
  const handleUpdateOrder = async (e) => {
    e.preventDefault();
    if (!selectedOrder?.id) return;

    setSaving(true);
    try {
      const token = sessionStorage.getItem('kemborn_token');
      const res = await fetch(`${API_URL}/api/admin/orders/${selectedOrder.id}`, {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(editForm)
      });

      if (res.ok) {
        toast.success("Sipariş başarıyla güncellendi!");
        setSelectedOrder(null); 
        fetchOrders(); 
      } else {
        const errData = await res.json();
        toast.error(errData.error || "Güncelleme başarısız.");
      }
    } catch (error) {
      toast.error("Sunucuya ulaşılamadı.");
    } finally {
      setSaving(false);
    }
  };

  // Düzenlenen Alan: Kayıpsız Filtreleme ve Tarihe Göre Yeniden Eskiye Sıralama (DESC)
  const filteredOrders = orders
    .filter(order => {
      const searchLower = String(searchTerm || '').toLowerCase();
      const customerName = String(order.customer_name || '').toLowerCase();
      const orderNo = String(order.order_number || '').toLowerCase();
      const matchesSearch = customerName.includes(searchLower) || orderNo.includes(searchLower);

      const currentStatus = String(order.status || '').trim().toUpperCase();
      const targetTab = String(activeTab || '').trim().toUpperCase();

      // "Toplam Sipariş" (ALL) filtresi tıklandığında doğrudan tüm arama eşleşmelerini getirir
      if (targetTab === 'ALL') return matchesSearch;
      
      // Düzenlenen Alan: Tamamlandı ve Teslim Edildi durumları tek sekmede kayıpsız birleştirildi
      if (targetTab === 'TAMAMLANDI') {
        return (currentStatus === 'TAMAMLANDI' || currentStatus === 'TESLİM EDİLDİ' || currentStatus === 'TESLIM EDILDI') && matchesSearch;
      }

      // Düzenlenen Alan: İptal Edilen sipariş varyasyonları korumaya alındı
      if (targetTab === 'İPTAL EDİLDİ' || targetTab === 'IPTAL EDILDI') {
        return (currentStatus === 'İPTAL EDİLDİ' || currentStatus === 'IPTAL EDILDI') && matchesSearch;
      }

      return currentStatus === targetTab && matchesSearch;
    })
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

  // Arama ya da sekme değişince sayfa 1'e dön (eski sayfada kalıp boş görünmesin)
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, activeTab]);

  const totalPages = Math.max(1, Math.ceil(filteredOrders.length / PAGE_SIZE));
  const pagedOrders = filteredOrders.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  const getStatusStyle = (status) => {
    switch(String(status || '').toUpperCase()) {
      case 'TAMAMLANDI': 
      case 'TESLİM EDİLDİ': 
      case 'TESLIM EDILDI': return 'bg-green-50 text-green-700 border-green-200';
      case 'HAZIRLANIYOR': return 'bg-orange-50 text-orange-700 border-orange-200';
      case 'KARGODA': return 'bg-cyan-50 text-cyan-700 border-cyan-200';
      case 'İPTAL EDİLDİ': 
      case 'IPTAL EDILDI': return 'bg-red-50 text-red-700 border-red-200';
      default: return 'bg-zinc-50 text-zinc-700 border-zinc-200';
    }
  };

  const handleTabChange = (tabName) => {
    setActiveTab(tabName);
    setSearchParams({ status: tabName });
  };

  return (
    <div className="animate-in fade-in duration-500 relative font-sans">
      <h1 className="text-3xl font-black text-zinc-900 mb-8">Sipariş Yönetimi</h1>

      {/* Düzenlenen Alan: İPTAL EDİLENLER SEKME BUTONU VE DİNAMİK SAYAÇLAR EKLENDİ */}
      <div className="flex flex-wrap gap-2 mb-6 bg-zinc-100 p-1.5 rounded-2xl w-fit border border-zinc-200 shadow-inner">
        <button onClick={() => handleTabChange('ALL')} className={`px-5 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all ${activeTab === 'ALL' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-900'}`}>Tüm Siparişler ({orders.length})</button>
        <button onClick={() => handleTabChange('HAZIRLANIYOR')} className={`px-5 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all ${activeTab === 'HAZIRLANIYOR' ? 'bg-white text-orange-600 shadow-sm' : 'text-zinc-500 hover:text-orange-600'}`}>Hazırlanıyor ({orders.filter(o => String(o.status || '').toUpperCase() === 'HAZIRLANIYOR').length})</button>
        <button onClick={() => handleTabChange('KARGODA')} className={`px-5 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all ${activeTab === 'KARGODA' ? 'bg-white text-cyan-600 shadow-sm' : 'text-zinc-500 hover:text-cyan-600'}`}>Kargoda Olanlar ({orders.filter(o => String(o.status || '').toUpperCase() === 'KARGODA').length})</button>
        <button onClick={() => handleTabChange('TAMAMLANDI')} className={`px-5 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all ${activeTab === 'TAMAMLANDI' ? 'bg-white text-emerald-600 shadow-sm' : 'text-zinc-500 hover:text-emerald-600'}`}>Tamamlananlar ({orders.filter(o => { const s = String(o.status || '').toUpperCase(); return s === 'TAMAMLANDI' || s === 'TESLİM EDİLDİ' || s === 'TESLIM EDILDI'; }).length})</button>
        <button onClick={() => handleTabChange('İPTAL EDİLDİ')} className={`px-5 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all ${activeTab === 'İPTAL EDİLDİ' || activeTab === 'IPTAL EDILDI' ? 'bg-white text-red-600 shadow-sm' : 'text-zinc-500 hover:text-red-600'}`}>İptal Edilenler ({orders.filter(o => { const s = String(o.status || '').toUpperCase(); return s === 'İPTAL EDİLDİ' || s === 'IPTAL EDILDI'; }).length})</button>
      </div>

      {/* Üst Bar: Arama Çubuğu */}
      <div className="mb-6 bg-white p-2 rounded-2xl border border-zinc-200 shadow-sm flex items-center">
        <div className="pl-4 text-zinc-400"><FiSearch size={20} /></div>
        <input 
          type="text" 
          placeholder="Sipariş numarası veya müşteri ismiyle anlık filtreleyin..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full p-3 bg-transparent outline-none font-bold text-zinc-700 placeholder:text-zinc-400 text-sm"
        />
      </div>

      {/* Siparişler Ana Tablosu — MASAÜSTÜ */}
      <div className="hidden md:block bg-white rounded-3xl border border-zinc-200 overflow-hidden shadow-sm overflow-x-auto">
        <table className="w-full text-left min-w-[720px]">
          <thead className="bg-zinc-50 border-b border-zinc-200">
            <tr>
              <th className="p-6 font-black text-zinc-400 uppercase text-xs">Sipariş No</th>
              <th className="p-6 font-black text-zinc-400 uppercase text-xs">Müşteri</th>
              <th className="p-6 font-black text-zinc-400 uppercase text-xs">Sipariş Tarihi</th>
              <th className="p-6 font-black text-zinc-400 uppercase text-xs">Toplam Tutar</th>
              <th className="p-6 font-black text-zinc-400 uppercase text-xs">Güncel Durum</th>
              <th className="p-6 font-black text-zinc-400 uppercase text-xs text-right">İşlemler</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-100">
            {loading ? (
              <tr><td colSpan="6" className="p-12 text-center text-zinc-400 font-bold animate-pulse">Sipariş veritabanı taranıyor...</td></tr>
            ) : pagedOrders.length === 0 ? (
              <tr><td colSpan="6" className="p-12 text-center text-zinc-400 font-bold">Bu sekmeye uygun herhangi bir sipariş kaydı bulunamadı.</td></tr>
            ) : (
              pagedOrders.map((order) => (
                <tr key={order.id} className="hover:bg-zinc-50/60 transition-colors">
                  <td className="p-6 font-black text-zinc-900 tracking-wide">{order.order_number || '-'}</td>
                  <td className="p-6 text-zinc-700 font-bold flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-500 border border-zinc-200 text-xs font-black">{String(order.customer_name || 'K').charAt(0).toUpperCase()}</div>
                    {order.customer_name || 'Bilinmeyen Müşteri'}
                  </td>
                  <td className="p-6 text-zinc-500 font-medium text-sm">
                    {order.created_at ? new Date(order.created_at).toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute:'2-digit' }) : '-'}
                  </td>
                  <td className="p-6 text-cyan-700 font-black">
                    {parseFloat(order.total_amount || 0).toLocaleString('tr-TR')} TL
                  </td>
                  <td className="p-6">
                    <span className={`px-3 py-1.5 rounded-full text-[10px] font-black border uppercase tracking-wider ${getStatusStyle(order.status)}`}>
                      {order.status || 'BELİRSİZ'}
                    </span>
                  </td>
                  <td className="p-6 text-right">
                    <button 
                      onClick={() => handleViewOrder(order.id)}
                      className="p-3 bg-zinc-50 border border-zinc-200 rounded-xl hover:bg-cyan-600 hover:text-white hover:border-cyan-600 transition-all text-zinc-600 shadow-sm"
                      title="Sipariş Detaylarını ve Ödemeyi İncele"
                    >
                      <FiEye size={18} />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Siparişler — MOBİL KART GÖRÜNÜMÜ */}
      <div className="md:hidden space-y-3">
        {loading ? (
          <p className="text-center text-zinc-400 font-bold animate-pulse py-8">Sipariş veritabanı taranıyor...</p>
        ) : pagedOrders.length === 0 ? (
          <p className="text-center text-zinc-400 font-bold py-8">Bu sekmeye uygun herhangi bir sipariş kaydı bulunamadı.</p>
        ) : (
          pagedOrders.map((order) => (
            <button
              key={order.id}
              onClick={() => handleViewOrder(order.id)}
              className="w-full text-left bg-white rounded-2xl border border-zinc-200 shadow-sm p-4"
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <span className="font-black text-zinc-900">{order.order_number || '-'}</span>
                <span className={`px-2.5 py-1 rounded-full text-[10px] font-black border uppercase tracking-wider shrink-0 ${getStatusStyle(order.status)}`}>
                  {order.status || 'BELİRSİZ'}
                </span>
              </div>
              <p className="text-sm text-zinc-600 font-bold mb-1">{order.customer_name || 'Bilinmeyen Müşteri'}</p>
              <div className="flex items-center justify-between text-sm">
                <span className="text-zinc-400">
                  {order.created_at ? new Date(order.created_at).toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '-'}
                </span>
                <span className="text-cyan-700 font-black">{parseFloat(order.total_amount || 0).toLocaleString('tr-TR')} TL</span>
              </div>
            </button>
          ))
        )}
      </div>

      {/* SAYFALAMA KONTROLLERİ */}
      {!loading && filteredOrders.length > PAGE_SIZE && (
        <div className="flex items-center justify-center gap-2 mt-6">
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="px-4 py-2 bg-white border border-zinc-200 rounded-xl font-bold text-sm text-zinc-600 disabled:opacity-30"
          >
            Önceki
          </button>
          <span className="px-4 py-2 font-bold text-sm text-zinc-500">
            Sayfa {currentPage} / {totalPages}
          </span>
          <button
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="px-4 py-2 bg-white border border-zinc-200 rounded-xl font-bold text-sm text-zinc-600 disabled:opacity-30"
          >
            Sonraki
          </button>
        </div>
      )}

      {/* MÜKEMMELLEŞTİRİLMİŞ SİPARİŞ DETAY VE DÜZENLEME MODALI */}
      {selectedOrder && (
        <div className="fixed inset-0 bg-zinc-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in">
          <div className="bg-white rounded-[2rem] w-full max-w-6xl max-h-[92vh] overflow-hidden shadow-2xl flex flex-col border border-zinc-100">
            
            <div className="flex items-center justify-between p-6 border-b border-zinc-100 bg-zinc-50/80">
              <div>
                <h2 className="text-2xl font-black text-zinc-900 flex items-center gap-3 leading-none">
                  <FiPackage className="text-cyan-600" /> Sipariş Kartı: {selectedOrder.order_number || 'Yükleniyor...'}
                </h2>
                <p className="text-xs font-bold text-zinc-400 mt-1.5 uppercase tracking-wider">Kemborn Güvenli Ödeme ve Lojistik Takip Ekranı</p>
              </div>
              <button onClick={() => setSelectedOrder(null)} className="p-2.5 bg-white text-zinc-400 border border-zinc-200 rounded-full hover:bg-red-50 hover:text-red-500 hover:border-red-200 transition-all shadow-sm">
                <FiX size={20} />
              </button>
            </div>

            <div className="p-6 overflow-y-auto flex-1 bg-white custom-scrollbar">
              {detailsLoading || !selectedOrder.items ? (
                <div className="flex justify-center items-center h-52">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-b-4 border-cyan-600"></div>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  
                  {/* SOL VE ORTA ALAN: MÜŞTERI, LOJİSTİK VE ÜRÜN BİLGİLERİ */}
                  <div className="lg:col-span-2 space-y-6">
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-zinc-50/50 p-5 rounded-2xl border border-zinc-100 flex items-center gap-4">
                        <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center border border-zinc-200 text-cyan-600 shadow-sm"><FiUser size={22}/></div>
                        <div>
                          <p className="text-[10px] font-black text-zinc-400 uppercase tracking-wider">Müşteri Sorumlusu</p>
                          <p className="font-black text-zinc-800 text-base mt-0.5">{selectedOrder.customer_name || 'Kemborn Kullanıcısı'}</p>
                        </div>
                      </div>
                      <div className="bg-zinc-50/50 p-5 rounded-2xl border border-zinc-100 flex items-center gap-4">
                        <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center border border-zinc-200 text-cyan-600 shadow-sm"><FiCreditCard size={22}/></div>
                        <div>
                          <p className="text-[10px] font-black text-zinc-400 uppercase tracking-wider">Ödeme Altyapısı</p>
                          <p className="font-black text-zinc-800 text-base mt-0.5">{selectedOrder.payment_method || 'iyzico Checkout Form'}</p>
                        </div>
                      </div>
                    </div>

                    {/* Adres Kutusu */}
                    <div className="bg-zinc-50 p-5 rounded-2xl border border-zinc-100">
                      <h3 className="font-black text-zinc-900 mb-3 text-sm flex items-center gap-2"><FiMapPin className="text-cyan-600"/> Gönderim ve Fatura Adresi</h3>
                      <p className="text-zinc-600 font-medium text-sm whitespace-pre-wrap leading-relaxed bg-white p-4 rounded-xl border border-zinc-100 shadow-inner">
                        {selectedOrder.shipping_address || 'Adres detayları veritabanında eksik veya girilmemiş.'}
                      </p>
                    </div>

                    {/* Sipariş Edilen Ürünler Listesi */}
                    <div>
                      <h3 className="font-black text-zinc-900 mb-3 text-sm flex items-center gap-2"><FiPackage className="text-cyan-600"/> Paketteki Ürünler</h3>
                      <div className="space-y-3">
                        {selectedOrder.items.map(item => (
                          <div key={item.id} className="bg-white border border-zinc-200 p-4 rounded-2xl flex justify-between items-center shadow-sm hover:border-zinc-300 transition-all">
                            <div className="flex items-center gap-4">
                              <div className="w-12 h-12 bg-zinc-50 rounded-xl flex items-center justify-center font-black text-zinc-700 border border-zinc-100 text-sm shadow-inner">
                                {item.quantity || 1}x
                              </div>
                              <div>
                                <p className="font-black text-zinc-800 text-sm">{item.product_name}</p>
                                <p className="text-[11px] font-black text-cyan-600 uppercase mt-1 bg-cyan-50 px-2.5 py-0.5 rounded-md border border-cyan-100 w-fit">
                                  Seçim: {item.color || 'Siyah (Standart)'}
                                </p>
                              </div>
                            </div>
                            <p className="font-black text-zinc-900 text-base">{parseFloat(item.price || 0).toLocaleString('tr-TR')} TL</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* SAĞ ALAN: LOJİSTİK YÖNETİM FORMU VE TARİH VERİLERİ */}
                  <div className="bg-zinc-50 p-6 rounded-2xl border border-zinc-100 h-fit sticky top-0 flex flex-col justify-between">
                    <div>
                      <h3 className="font-black text-zinc-900 mb-5 text-sm flex items-center gap-2 border-b border-zinc-200 pb-4 uppercase tracking-wider">Durum & Kargo Ayarı</h3>
                      
                      <form onSubmit={handleUpdateOrder} className="space-y-5">
                        
                        <div className="space-y-2">
                          <label className="text-[11px] font-black text-zinc-400 uppercase tracking-wider">Sipariş Durumu</label>
                          <select 
                            value={editForm.status}
                            onChange={(e) => setEditForm({...editForm, status: e.target.value})}
                            className="w-full p-4 bg-white border border-zinc-200 rounded-xl font-black text-zinc-800 text-sm outline-none focus:border-cyan-600 transition-all shadow-sm cursor-pointer"
                          >
                            <option value="HAZIRLANIYOR">🛠️ HAZIRLANIYOR</option>
                            <option value="KARGODA">📦 KARGODA</option>
                            <option value="TAMAMLANDI">✅ TAMAMLANDI</option>
                            <option value="İPTAL EDİLDİ">❌ İPTAL EDİLDİ</option>
                          </select>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[11px] font-black text-zinc-400 uppercase tracking-wider flex items-center gap-1"><FiTruck/> Barkod / Kargo Takip No</label>
                          <input 
                            type="text"
                            value={editForm.tracking_number}
                            onChange={(e) => setEditForm({...editForm, tracking_number: e.target.value})}
                            placeholder="Müşteriye gidecek takip kodunu girin..."
                            className="w-full p-4 bg-white border border-zinc-200 rounded-xl font-bold text-zinc-800 text-sm outline-none focus:border-cyan-600 transition-all shadow-sm placeholder:text-zinc-300"
                          />
                        </div>

                        <div className="pt-4 border-t border-zinc-200 space-y-4">
                          <div className="flex justify-between items-center text-xs text-zinc-400 font-bold bg-white p-3 rounded-xl border border-zinc-100 shadow-inner">
                            <span className="flex items-center gap-1"><FiCalendar/> İşlem Tarihi:</span>
                            <span className="text-zinc-700 font-black">{selectedOrder.created_at ? new Date(selectedOrder.created_at).toLocaleDateString('tr-TR') : '-'}</span>
                          </div>

                          <div className="flex justify-between items-center pt-2">
                            <span className="font-black text-zinc-400 text-xs uppercase tracking-wider">Genel Hakediş</span>
                            <span className="text-2xl font-black text-cyan-700 tracking-tight">{parseFloat(selectedOrder.total_amount || 0).toLocaleString('tr-TR')} TL</span>
                          </div>
                          
                          <button 
                            type="submit"
                            disabled={saving}
                            className={`w-full py-4 rounded-xl font-black text-sm text-white flex items-center justify-center gap-2 transition-all ${
                              saving ? 'bg-zinc-400 cursor-not-allowed' : 'bg-zinc-900 hover:bg-cyan-600 shadow-md shadow-zinc-900/10'
                            }`}
                          >
                            <FiSave size={18} /> {saving ? 'Veritabanı Yazılıyor...' : 'Siparişi Güncelle'}
                          </button>
                        </div>

                      </form>
                    </div>
                  </div>

                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminOrders;