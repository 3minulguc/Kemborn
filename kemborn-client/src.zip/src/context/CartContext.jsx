import React, { createContext, useContext, useState, useEffect } from 'react';
import toast from 'react-hot-toast';

const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState(() => {
    try {
      const savedCart = localStorage.getItem('kemborn-cart');
      return savedCart ? JSON.parse(savedCart) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem('kemborn-cart', JSON.stringify(cart));
  }, [cart]);

  // FİYAT DÜZELTİCİ: String (1.220 TL) veya Sayı (1220) olarak gelen her şeyi sayıya çevirir
  const cleanPrice = (price) => {
    if (typeof price === 'number') return price;
    if (typeof price !== 'string') return 0;
    // Nokta, virgül ve para birimi kısımlarını temizleyip sadece rakamı bırakır
    return parseFloat(price.replace(/[^0-9.]/g, '')) || 0;
  };

  const addToCart = (product, quantity = 1, color = 'Siyah') => {
    const price = cleanPrice(product.price);
    const uniqueKey = `${product.id}-${color}`;

    setCart((prev) => {
      const existingItem = prev.find(item => item.uniqueKey === uniqueKey);

      if (existingItem) {
        return prev.map(item => 
          item.uniqueKey === uniqueKey 
            ? { ...item, quantity: item.quantity + quantity } 
            : item
        );
      }
      
      return [...prev, { 
        ...product, 
        price, 
        quantity, 
        color, 
        uniqueKey 
      }];
    });
    
    toast.success(`${product.name} sepete eklendi!`);
  };

  const increaseQuantity = (uniqueKey) => {
    setCart((prev) => prev.map((item) => 
      item.uniqueKey === uniqueKey 
        ? { ...item, quantity: item.quantity + 1 } 
        : item
    ));
  };

  const decreaseQuantity = (uniqueKey) => {
    setCart((prev) => prev.map((item) => 
      item.uniqueKey === uniqueKey && item.quantity > 1 
        ? { ...item, quantity: item.quantity - 1 } 
        : item
    ));
  };

  const removeFromCart = (uniqueKey) => {
    setCart((prev) => prev.filter((item) => item.uniqueKey !== uniqueKey));
  };

  // --- SEPETTEKİ BİR ÜRÜNÜN RENGİNİ DEĞİŞTİRME ---
  const updateColor = (oldUniqueKey, newColor) => {
    setCart((prev) => {
      const item = prev.find(i => i.uniqueKey === oldUniqueKey);
      if (!item || item.color === newColor) return prev;

      const newUniqueKey = `${item.id}-${newColor}`;
      const existingWithNewColor = prev.find(i => i.uniqueKey === newUniqueKey);

      if (existingWithNewColor) {
        // Sepette o renkte zaten bir satır varsa, miktarları birleştirip eski satırı kaldır
        return prev
          .filter(i => i.uniqueKey !== oldUniqueKey)
          .map(i => i.uniqueKey === newUniqueKey ? { ...i, quantity: i.quantity + item.quantity } : i);
      }

      return prev.map(i => i.uniqueKey === oldUniqueKey ? { ...i, color: newColor, uniqueKey: newUniqueKey } : i);
    });
  };

  const clearCart = () => setCart([]);

  return (
    <CartContext.Provider value={{ 
      cart, 
      addToCart, 
      increaseQuantity, 
      decreaseQuantity, 
      removeFromCart, 
      updateColor,
      clearCart 
    }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);